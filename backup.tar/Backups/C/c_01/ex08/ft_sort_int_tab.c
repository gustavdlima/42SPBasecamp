void	ft_swap(int *a, int*b)
{
	int	swap;

	swap = *b;
	*b = *a;
	*a = swap;
}

void	ft_sort_int_tab(int *tab, int size)
{
	int	i;
	int	j;

	i = 0;
	while (i < size)
	{
		j = 0;
		while (j < size)
		{
			if (tab[i] <= tab[j])
			{
				ft_swap(&tab[j], &tab[i]);
			}
			j++;
		}
		i++;
	}
}
