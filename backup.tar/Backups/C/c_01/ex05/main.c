void	ft_putstr(char *str);

int	main(void)
{
	char	*str = "alowgalera";

	ft_putstr(str);
	return (0);
}
